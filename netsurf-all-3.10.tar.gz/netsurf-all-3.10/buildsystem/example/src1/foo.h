#ifndef foo_h_
#define foo_h_

extern int foo(void);

#endif
