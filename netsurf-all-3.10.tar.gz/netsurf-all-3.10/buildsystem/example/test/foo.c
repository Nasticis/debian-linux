#include <stdio.h>

#include "foo.h"

int main(void)
{
	foo();

	printf("PASS\n");

	return 0;
}
